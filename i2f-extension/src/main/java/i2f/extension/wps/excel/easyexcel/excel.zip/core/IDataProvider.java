package i2f.extension.wps.excel.core;


import java.util.List;

/**
 * @author ltb
 * @date 2021/10/19
 */
public interface IDataProvider {
    void preProcess();
    boolean supportPage();
    List<?> getData(ExcelExportPage page);
    Class<?> getDataClass();
}
