package com.newland.bi3.common.core.utils.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.newland.bi3.common.core.utils.excel.core.ExcelExportPage;
import com.newland.bi3.common.core.utils.excel.core.ExcelExportTask;
import com.newland.bi3.common.core.utils.excel.core.IDataProvider;
import com.newland.bi3.common.core.utils.uuid.UUID;
import lombok.Data;
import lombok.Getter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * @author Ice2Faith
 * @date 2024/1/29 9:43
 * @desc
 */
public class ExcelExportUtil {
    public static File write(IDataProvider provider, File file){
        ExcelExportTask task = new ExcelExportTask(provider,file,null,null,null);
        task.run();
        return task.getFile();
    }

    public static File write(IDataProvider provider, File file, String sheetName){
        ExcelExportTask task = new ExcelExportTask(provider,file,sheetName,null,null);
        task.run();
        return task.getFile();
    }

    public static File write(IDataProvider provider, File file, String sheetName, File templateFile){
        ExcelExportTask task = new ExcelExportTask(provider,file,sheetName,templateFile,null);
        task.run();
        return task.getFile();
    }

    public static File write(IDataProvider provider, File file, String sheetName, File templateFile, File tmpFile){
        ExcelExportTask task = new ExcelExportTask(provider,file,sheetName,templateFile,tmpFile);
        task.run();
        return task.getFile();
    }

    public static File write(IDataProvider provider, File file, String sheetName, File templateFile, File tmpFile, Consumer<ExcelExportTask> taskConsumer){
        ExcelExportTask task = new ExcelExportTask(provider,file,sheetName,templateFile,tmpFile);
        if(taskConsumer!=null){
            taskConsumer.accept(task);
        }
        task.run();
        return task.getFile();
    }
}
