package i2f.extension.wps.excel.core.impl;


import i2f.extension.wps.excel.core.IDataProvider;
import lombok.Data;

/**
 * @author ltb
 * @date 2021/10/19
 */
@Data
public abstract class AbsDataProviderAdapter implements IDataProvider {
    protected Object[] params;

    @Override
    public void preProcess() {

    }

}
