db.createUser(
    {
        user: "zqq",
        pwd: "No1Bug2Please3!",
        roles: [
            {
                role: "readWrite",
                db: "powerjob_daily"
            }
        ]
    }
);
