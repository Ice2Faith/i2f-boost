/**
 * Spring 通用能力包
 *
 * @author tjq
 * @since 2023/7/30
 */
package tech.powerjob.server.common.spring;