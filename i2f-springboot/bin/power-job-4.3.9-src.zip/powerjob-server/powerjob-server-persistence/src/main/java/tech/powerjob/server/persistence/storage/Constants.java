package tech.powerjob.server.persistence.storage;

/**
 * Constants
 *
 * @author tjq
 * @since 2023/7/30
 */
public class Constants {

    public static final String LOG_BUCKET = "log";

    public static final String CONTAINER_BUCKET = "container";

}
