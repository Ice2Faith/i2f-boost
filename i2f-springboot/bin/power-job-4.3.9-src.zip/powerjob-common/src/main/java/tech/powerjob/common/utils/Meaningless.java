package tech.powerjob.common.utils;

/**
 * 毫无意义就是最大的意义
 *
 * @author tjq
 * @since 2020/5/16
 */
@FunctionalInterface
public interface Meaningless {
    void m() throws Exception;
}
