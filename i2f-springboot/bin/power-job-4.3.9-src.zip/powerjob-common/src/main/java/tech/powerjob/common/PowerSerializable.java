package tech.powerjob.common;

import java.io.Serializable;

/**
 * PowerJob serializable interface.
 *
 * @author tjq
 * @since 2020/4/16
 */
public interface PowerSerializable extends Serializable {
}
