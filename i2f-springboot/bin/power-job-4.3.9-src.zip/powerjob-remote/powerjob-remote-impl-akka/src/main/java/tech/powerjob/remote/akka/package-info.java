/**
 * 由于 AKKA 后续转向收费运营模式，PowerJob 计划移除 akka 支持，因此不再维护该 module。
 * 如果存在任何使用上的问题，请切换到其他通讯协议（建议使用 HTTP）
 *
 * @author PowerJob发言人
 * @since 2022/12/31
 */
package tech.powerjob.remote.akka;